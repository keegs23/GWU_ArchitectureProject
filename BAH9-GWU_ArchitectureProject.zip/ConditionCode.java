public enum ConditionCode
{
    OVERFLOW,
    UNDERFLOW,
    DIVZERO,
    EQUALORNOT
}