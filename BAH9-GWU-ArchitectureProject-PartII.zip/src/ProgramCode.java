public enum ProgramCode 
{
	BOOTPROGRAM,	//0
	PROGRAMONE,		//1
	PROGRAMTWO		//2
}
