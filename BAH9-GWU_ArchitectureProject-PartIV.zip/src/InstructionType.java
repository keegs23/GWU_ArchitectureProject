
public enum InstructionType {
	BRANCH,
	STORE,
	REGISTER

}
