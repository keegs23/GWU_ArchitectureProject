public enum ConditionCode
{
    OVERFLOW,	//0
    UNDERFLOW,	//1
    DIVZERO,	//2
    EQUALORNOT	//3
}